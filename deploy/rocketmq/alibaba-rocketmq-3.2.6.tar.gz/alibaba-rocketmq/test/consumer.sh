#!/bin/sh

#
# $Id: consumer.sh 1831 2013-05-16 01:39:51Z shijia.wxr $
#
sh ./runclass.sh com.alibaba.rocketmq.example.operation.Consumer $@
